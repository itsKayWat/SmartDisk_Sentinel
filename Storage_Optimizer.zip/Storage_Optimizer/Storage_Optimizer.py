import os
import tkinter as tk
from tkinter import ttk, messagebox
import sys
from typing import List, Dict, Tuple
import threading
from datetime import datetime
import time
import re
import shutil

class SmartStorageOptimizer:
    def __init__(self):
        # Initialize root window
        self.root = tk.Tk()
        self.root.title("Smart Storage Optimizer")
        self.root.geometry("1200x800")
        
        # Enhanced dark emerald theme
        self.bg_color = "#0A1F0A"  # Dark emerald background
        self.fg_color = "#E0E0E0"  # Light gray text
        self.accent_color = "#1A2F1A"  # Lighter emerald
        self.highlight_color = "#2D4F2D"  # Emerald highlight
        self.border_color = "#FFFFFF"  # White borders
        self.button_bg = "#234223"  # Button background
        self.button_fg = "#FFFFFF"  # Button text
        self.delete_button_bg = "#4F1F1F"  # Dark red for delete
        
        # Configure root
        self.root.configure(bg=self.bg_color)
        
        # Initialize variables
        self.recommendations = []
        self.current_batch_index = 0
        self.batch_size = 5
        self.workstation_active = False
        self.overlay = None
        self.recommendation_windows = []
        
        # File patterns for smart detection
        self.pattern_rules = {
            "temp_files": r".*\.(tmp|temp)$",
            "logs": r".*\.log$",
            "downloads": r".*downloads.*",
            "old_files": r".*\.(old|bak)$",
            "large_media": r".*\.(mp4|mkv|avi|mov)$",
            "duplicate_pattern": r".*\(\d+\).*"
        }
        
        # Create UI
        self.create_ui()

    def create_ui(self):
        # Main container
        self.main_frame = tk.Frame(self.root, bg=self.bg_color)
        self.main_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Drive selection frame
        self.create_drive_frame()
        
        # Status and recommendations frame
        self.create_status_frame()
        
        # Workstation button frame
        self.create_workstation_frame()

    def create_drive_frame(self):
        drive_frame = tk.Frame(self.main_frame, bg=self.bg_color)
        drive_frame.pack(fill='x', pady=10)
        
        # Drive selection
        drives = self.get_drives()
        self.drive_var = tk.StringVar(value=drives[0] if drives else "")
        
        tk.Label(
            drive_frame,
            text="Select Drive:",
            bg=self.bg_color,
            fg=self.fg_color,
            font=('Arial', 12, 'bold')
        ).pack(side='left', padx=5)
        
        drive_menu = tk.OptionMenu(drive_frame, self.drive_var, *drives)
        drive_menu.config(
            bg=self.button_bg,
            fg=self.fg_color,
            activebackground=self.highlight_color,
            activeforeground=self.fg_color
        )
        drive_menu.pack(side='left', padx=5)
        
        # Scan button
        self.scan_button = tk.Button(
            drive_frame,
            text="Start Smart Scan",
            command=self.start_smart_scan,
            bg=self.button_bg,
            fg=self.fg_color,
            activebackground=self.highlight_color,
            font=('Arial', 12, 'bold'),
            padx=20,
            pady=5
        )
        self.scan_button.pack(side='left', padx=20)

    def create_status_frame(self):
        """Enhanced status frame with dual-panel display"""
        self.status_frame = tk.Frame(self.main_frame, bg=self.bg_color)
        self.status_frame.pack(fill='both', expand=True, pady=10)
        
        # Status label at top
        self.status_label = tk.Label(
            self.status_frame,
            text="Ready to scan...",
            bg=self.accent_color,
            fg=self.fg_color,
            font=('Arial', 11),
            wraplength=800,
            padx=10,
            pady=10
        )
        self.status_label.pack(fill='x', pady=5)
        
        # Create split panel frame
        panel_frame = tk.Frame(self.status_frame, bg=self.bg_color)
        panel_frame.pack(fill='both', expand=True, pady=5)
        
        # Left panel: Smart Recommendations Bank
        self.create_recommendation_bank(panel_frame)
        
        # Right panel: Itemized List
        self.create_itemized_list(panel_frame)

    def create_recommendation_bank(self, parent):
        """Creates the smart recommendation bank panel"""
        bank_frame = tk.Frame(parent, bg=self.bg_color)
        bank_frame.pack(side='left', fill='both', expand=True, padx=(0, 5))
        
        # Header
        tk.Label(
            bank_frame,
            text="Smart Recommendations",
            bg=self.bg_color,
            fg="#90EE90",  # Light green text
            font=('Arial', 12, 'bold')
        ).pack(fill='x', pady=5)
        
        # Create category frames with dark emerald styling
        categories = [
            ("unused_files", "Unused Files (180+ days)"),
            ("large_files", "Large Files (1GB+)"),
            ("old_files", "Old Downloads & Temp Files")
        ]
        
        for cat_id, cat_name in categories:
            frame = tk.Frame(bank_frame, bg=self.bg_color)
            frame.pack(fill='x', pady=5, padx=5)
            
            # Category header
            tk.Label(
                frame,
                text=cat_name,
                bg=self.accent_color,
                fg="#90EE90",  # Light green text
                font=('Arial', 10, 'bold'),
                padx=5,
                pady=2
            ).pack(fill='x')
            
            # Listbox for files
            listbox = tk.Listbox(
                frame,
                bg="#0A1F0A",  # Very dark green
                fg=self.fg_color,
                selectbackground="#234223",  # Darker emerald for selection
                selectforeground=self.fg_color,
                height=6,
                font=('Arial', 9),
                relief='solid',
                borderwidth=1
            )
            listbox.pack(fill='both', expand=True, pady=2)
            
            # Store listbox reference
            setattr(self, f'{cat_id}_listbox', listbox)

    def create_itemized_list(self, parent):
        """Creates the itemized list panel"""
        list_frame = tk.Frame(parent, bg=self.bg_color)
        list_frame.pack(side='right', fill='both', expand=True, padx=(5, 0))
        
        # Treeview for itemized list
        self.file_tree = ttk.Treeview(
            list_frame,
            columns=("Size", "Age", "Reason"),
            show="headings",
            height=10
        )
        
        # Configure columns
        self.file_tree.heading("Size", text="Size (MB)")
        self.file_tree.heading("Age", text="Age (days)")
        self.file_tree.heading("Reason", text="Recommendation Reason")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.file_tree.yview)
        self.file_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack elements
        self.file_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def create_workstation_frame(self):
        self.workstation_frame = tk.Frame(self.main_frame, bg=self.bg_color)
        self.workstation_frame.pack(fill='x', pady=10)
        
        self.workstation_button = tk.Button(
            self.workstation_frame,
            text="Enter Workstation Mode",
            command=self.toggle_workstation_mode,
            bg=self.highlight_color,
            fg=self.fg_color,
            font=('Arial', 12, 'bold'),
            state='disabled',
            padx=20,
            pady=10
        )
        self.workstation_button.pack(side='right')

    def start_smart_scan(self):
        """Initiates the smart scan process"""
        self.scan_button.config(state='disabled')
        self.status_label.config(text="Scanning in progress...")
        self.recommendations = []
        
        # Start scan in background thread
        scan_thread = threading.Thread(target=self.perform_scan)
        scan_thread.daemon = True
        scan_thread.start()

    def perform_scan(self):
        """Enhanced scanning process"""
        drive = self.drive_var.get()
        files_scanned = 0
        total_size = 0
        
        for root, _, files in os.walk(drive):
            for file in files:
                try:
                    file_path = os.path.join(root, file)
                    files_scanned += 1
                    
                    # Get file info
                    file_stat = os.stat(file_path)
                    size_mb = file_stat.st_size / (1024 * 1024)
                    age_days = (time.time() - file_stat.st_mtime) / (24 * 3600)
                    
                    # Check if file should be recommended
                    reason = self.get_recommendation_reason(file_path, size_mb, age_days)
                    if reason:
                        self.recommendations.append((file_path, size_mb, reason))
                        total_size += size_mb
                        self.update_recommendations(files_scanned, total_size)
                
                except (PermissionError, OSError):
                    continue
        
        # Scan complete
        self.root.after(0, lambda: self.scan_complete(files_scanned, total_size))

    def get_recommendation_reason(self, file_path: str, size_mb: float, age_days: float) -> str:
        """Enhanced smart file detection"""
        try:
            # Skip system directories and files
            if any(sys_dir in file_path.lower() for sys_dir in [
                'windows', 'program files', 'appdata', '$recycle.bin', 'system32'
            ]):
                return ""
            
            file_name = os.path.basename(file_path).lower()
            
            # Skip system files and temporary files
            if file_name.startswith(('.', '$')) or file_name in ['desktop.ini', 'thumbs.db']:
                return ""
            
            if size_mb >= 1000:  # Files larger than 1GB
                return f"Very large file ({size_mb:.1f}MB)"
            elif age_days > 180:  # Files not accessed in 6 months
                return f"Old file, not accessed in {age_days:.0f} days"
            elif size_mb >= 100:  # Files larger than 100MB
                if any(ext in file_name for ext in ['.mp4', '.mov', '.avi', '.mkv']):
                    return f"Large media file ({size_mb:.1f}MB)"
                return f"Large file ({size_mb:.1f}MB)"
            
            return ""
        except:
            return ""

    def update_status(self, message: str):
        """Updates the status label"""
        self.root.after(0, lambda: self.status_label.config(text=message))

    def update_recommendations(self, files_scanned: int, total_size: float):
        """Real-time updates with reduced UI updates"""
        if files_scanned % 50 != 0 and files_scanned != 1:  # Update every 50 files
            return
        
        def update_ui():
            # Update scan status
            self.status_label.config(
                text=f"Scanned {files_scanned:,} files..."
            )
            
            # Update tree and recommendation bank
            if self.recommendations:
                latest = self.recommendations[-1]
                file_path, size_mb, reason = latest
                age_days = (time.time() - os.path.getmtime(file_path)) / (24 * 3600)
                
                # Add to tree
                self.file_tree.insert(
                    "",
                    0,  # Insert at top
                    values=(f"{size_mb:.1f}", f"{age_days:.0f}", reason)
                )
                
                # Add to appropriate recommendation bank
                file_name = os.path.basename(file_path)
                entry = f"{file_name} ({size_mb:.1f}MB)"
                
                if age_days > 180:
                    self.unused_files_listbox.insert(0, entry)
                elif size_mb > 1000:
                    self.large_files_listbox.insert(0, entry)
                elif 'download' in file_path.lower() or file_path.endswith(('.tmp', '.temp')):
                    self.old_files_listbox.insert(0, entry)
                
                # Enable workstation button if we have enough recommendations
                if len(self.recommendations) >= self.batch_size:
                    self.workstation_button.config(state='normal')
        
        # Schedule UI update
        self.root.after(0, update_ui)

    def scan_complete(self, files_scanned: int, total_size: float):
        """Handles scan completion"""
        self.root.after(0, lambda: [
            self.scan_button.config(state='normal'),
            self.workstation_button.config(state='normal'),
            self.status_label.config(
                text=f"Scan Complete!\n"
                     f"Files Scanned: {files_scanned:,}\n"
                     f"Potential Space Savings: {total_size:.1f}MB\n"
                     f"Click 'Enter Workstation Mode' to review {len(self.recommendations)} recommendations"
            ),
            messagebox.showinfo("Scan Complete", 
                              f"Found {len(self.recommendations)} items to review")
        ])

    def toggle_workstation_mode(self):
        """Toggles workstation mode"""
        if not self.workstation_active:
            self.enter_workstation_mode()
        else:
            self.exit_workstation_mode()

    def enter_workstation_mode(self):
        """Enhanced workstation mode entry"""
        if not self.recommendations:
            messagebox.showinfo("No Recommendations", "No files to review.")
            return
        
        self.workstation_active = True
        self.create_overlay()
        
        # Sort recommendations by size before showing
        self.recommendations.sort(key=lambda x: x[1], reverse=True)
        self.current_batch_index = 0
        self.show_recommendation_batch()

    def create_overlay(self):
        """Creates the workstation overlay"""
        self.overlay = tk.Toplevel(self.root)
        self.overlay.attributes('-alpha', 0.95)
        self.overlay.configure(bg=self.bg_color)
        self.overlay.attributes('-fullscreen', True)
        
        # Exit button
        tk.Button(
            self.overlay,
            text="Exit Workstation Mode",
            command=self.exit_workstation_mode,
            bg=self.delete_button_bg,
            fg=self.fg_color,
            font=('Arial', 12, 'bold')
        ).pack(pady=20)

    def show_recommendation_batch(self):
        """Shows current batch of recommendations with error handling"""
        if not self.recommendations:
            self.exit_workstation_mode()
            return
        
        start_idx = self.current_batch_index
        end_idx = min(start_idx + self.batch_size, len(self.recommendations))
        batch = self.recommendations[start_idx:end_idx]
        
        # Clear any existing recommendation windows
        for window in self.recommendation_windows:
            if window.winfo_exists():
                window.destroy()
        self.recommendation_windows.clear()
        
        # Create new recommendation windows
        for i, (file_path, size_mb, reason) in enumerate(batch):
            try:
                window = self.create_recommendation_window(file_path, size_mb, reason, i)
                self.recommendation_windows.append(window)
            except Exception as e:
                print(f"Error creating recommendation window: {e}")

    def create_recommendation_window(self, file_path: str, size_mb: float, reason: str, position: int):
        """Creates a recommendation window with better positioning"""
        win = tk.Toplevel(self.overlay)
        win.configure(bg=self.accent_color)
        
        # Calculate window size and position
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        win_width = min(screen_width // 3, 500)  # Max width of 500
        win_height = min(screen_height // 3, 300)  # Max height of 300
        
        # Adjust positioning to be more centered
        total_width = (win_width * 3) + 40  # 3 windows with 20px padding
        start_x = (screen_width - total_width) // 2
        start_y = (screen_height - (win_height * 2)) // 2
        
        x = start_x + (position % 3) * (win_width + 20)
        y = start_y + (position // 3) * (win_height + 20)
        
        win.geometry(f"{win_width}x{win_height}+{x}+{y}")
        
        # Prevent window resize
        win.resizable(False, False)
        
        # Add window content
        self.create_recommendation_content(win, file_path, size_mb, reason, position, win_width)
        
        return win

    def create_recommendation_content(self, win, file_path, size_mb, reason, position, win_width):
        """Creates the content for a recommendation window"""
        # Title
        tk.Label(
            win,
            text=f"Recommendation {position + 1}",
            bg=self.accent_color,
            fg=self.fg_color,
            font=('Arial', 14, 'bold')
        ).pack(pady=10)
        
        # File info
        info_frame = tk.Frame(win, bg=self.accent_color)
        info_frame.pack(fill='both', expand=True, padx=10)
        
        info_text = (
            f"Size: {size_mb:.1f}MB\n"
            f"Reason: {reason}\n\n"
            f"Path: {file_path}"
        )
        
        tk.Label(
            info_frame,
            text=info_text,
            bg=self.accent_color,
            fg=self.fg_color,
            wraplength=win_width-40,
            justify='left'
        ).pack(fill='both', expand=True)
        
        # Buttons
        button_frame = tk.Frame(win, bg=self.accent_color)
        button_frame.pack(side='bottom', pady=10)
        
        buttons = [
            ("Delete", self.delete_button_bg, lambda: self.delete_file(file_path, win)),
            ("Move", self.button_bg, lambda: self.move_file(file_path, win)),
            ("Copy", self.button_bg, lambda: self.copy_file(file_path, win)),
            ("Skip", self.button_bg, lambda: self.skip_file(file_path, win))
        ]
        
        for text, bg_color, command in buttons:
            tk.Button(
                button_frame,
                text=text,
                command=command,
                bg=bg_color,
                fg=self.fg_color,
                width=8,
                relief='solid',
                borderwidth=1
            ).pack(side='left', padx=5)

    def delete_file(self, file_path: str, window: tk.Toplevel):
        """Handles file deletion"""
        try:
            if messagebox.askyesno("Confirm Deletion", 
                                 f"Are you sure you want to delete:\n{file_path}?"):
                os.remove(file_path)
                window.destroy()
                self.recommendations = [r for r in self.recommendations 
                                      if r[0] != file_path]
                self.check_batch_complete()
        except Exception as e:
            messagebox.showerror("Error", f"Could not delete file: {str(e)}")

    def skip_file(self, file_path: str, window: tk.Toplevel):
        """Handles file skipping"""
        window.destroy()
        self.recommendations = [r for r in self.recommendations 
                              if r[0] != file_path]
        self.check_batch_complete()

    def check_batch_complete(self):
        """Checks if current batch is complete"""
        if not any(window.winfo_exists() 
                  for window in self.overlay.winfo_children() 
                  if isinstance(window, tk.Toplevel)):
            self.current_batch_index += self.batch_size
            self.show_recommendation_batch()

    def exit_workstation_mode(self):
        """Exits workstation mode"""
        self.workstation_active = False
        if self.overlay:
            self.overlay.destroy()
            self.overlay = None
        self.current_batch_index = 0

    def get_drives(self) -> List[str]:
        """Gets available drives"""
        if sys.platform == "win32":
            return [f"{d}:\\" for d in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 
                    if os.path.exists(f"{d}:")]
        return ["/"]

    def run(self):
        """Starts the application"""
        self.root.mainloop()

    def move_file(self, file_path: str, window: tk.Toplevel):
        """Handle moving files"""
        from tkinter import filedialog
        try:
            dest_dir = filedialog.askdirectory(title="Select Destination Directory")
            if dest_dir:
                new_path = os.path.join(dest_dir, os.path.basename(file_path))
                shutil.move(file_path, new_path)
                window.destroy()
                self.recommendations = [r for r in self.recommendations if r[0] != file_path]
                self.check_batch_complete()
        except Exception as e:
            messagebox.showerror("Error", f"Could not move file: {str(e)}")

    def copy_file(self, file_path: str, window: tk.Toplevel):
        """Handle copying files"""
        from tkinter import filedialog
        try:
            dest_dir = filedialog.askdirectory(title="Select Destination Directory")
            if dest_dir:
                new_path = os.path.join(dest_dir, os.path.basename(file_path))
                shutil.copy2(file_path, new_path)
                window.destroy()
                self.recommendations = [r for r in self.recommendations if r[0] != file_path]
                self.check_batch_complete()
        except Exception as e:
            messagebox.showerror("Error", f"Could not copy file: {str(e)}")

if __name__ == "__main__":
    app = SmartStorageOptimizer()
    app.run()